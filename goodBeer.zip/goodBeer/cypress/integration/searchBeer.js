import { PassThrough } from "stream";

describe('get beers', () => {
    it('get beers', () => {
       cy.request('GET', 'beers?yeast=Wyeast-3522-Belgian-Ardennes&hops=Tomahawk')
       .then((response)=>{
           const hops = response.hops;
           for (i=0; i<hops.length; i++){
               if (hops[i].name === `magnum`){
                   if(hops[i].amount.value === 12.5){
                       return;
                   }
               }
           }
       });
    });
 });