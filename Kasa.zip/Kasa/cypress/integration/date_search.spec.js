import * as homeScreen from '../pageObjects/homeScreen';

describe('date search', () => {
    it('user is unable to search for a date in the past', () => {
        cy.visit('https://kasa.com/');
        homeScreen.dismissPromoModal();
        cy.get(homeScreen.homeScreenCheckInDate).click();
        cy.get('.asd__change-month-button--previous > button').click();
        cy.get('[data-date="2022-02-01"] > .asd__day-button').should('be.disabled');
    });
  })