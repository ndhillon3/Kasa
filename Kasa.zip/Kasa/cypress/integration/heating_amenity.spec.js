import * as homeScreen from '../pageObjects/homeScreen';

describe('heating amenity', () => {
    it('user can confirm kasa has heating amenity', () => {
        cy.visit('https://kasa.com/');
        homeScreen.dismissPromoModal();
        cy.get(homeScreen.homeScreenLocationSearchBar).click().type('Austin');
        cy.get(homeScreen.homeScreenListFirstItem).click();
        cy.get(homeScreen.homeScreenCheckInDate).type('04/01/2022');
        cy.get(homeScreen.homeScreenCheckOutDate).type('04/10/2022');
        cy.get(homeScreen.homeScreenGuestCount).type('{enter}');
        cy.wait(1000);
        cy.contains('View details').click();
        cy.wait(1000);
        cy.get('#room-type-card--605c9ce8de8c651b7f15f0d6 > .link-text').click();
        cy.get('div.room-type-popup__section-distance').contains('Heating')
    });
  })