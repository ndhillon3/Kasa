import * as homeScreen from '../pageObjects/homeScreen';
import * as searchResults from '../pageObjects/searchResults';

describe('location search', () => {
    it('user can search for a kasa in Austin, TX', () => {
        cy.visit('https://kasa.com/');
        homeScreen.dismissPromoModal();
        cy.get(homeScreen.homeScreenLocationSearchBar).click().type('Austin');
        cy.get(homeScreen.homeScreenListFirstItem).click();
        cy.get(homeScreen.homeScreenCheckInDate).type('04/01/2022');
        cy.get(homeScreen.homeScreenCheckOutDate).type('04/02/2022');
        cy.get(homeScreen.homeScreenGuestCount).type('{enter}');
        cy.get(searchResults.searchResultsPageHeader).contains('Austin, TX');
        cy.get(searchResults.searchResultsContent).contains('Minimum 2-night stays at this property')
    });

    it('user can re-do search in San Francisco', () => {
        cy.get(searchResults.searchBar).click().clear().type('San Francisco, CA');
        cy.contains('Search').click();
        cy.wait(1000);
        cy.get(searchResults.searchResultsPageHeader).contains('San Francisco, CA');
        cy.get(searchResults.searchResultsContent).contains('Minimum 2-night stays at this property')
    });

    it('user can re-do search in Chicago', () => {
        cy.get(searchResults.searchBar).click().clear().type('Chicago, IL');
        cy.contains('Search').click();
        cy.wait(1000);
        cy.get(searchResults.searchResultsPageHeader).contains('Chicago, IL');
        cy.get(searchResults.searchResultsContent).contains('Minimum 2-night stays at this property')
    })
  })