function dismissPromoModal() {
    cy.wait(10000);
    cy.visit('https://kasa.com/');
  }

  const homeScreenLocationSearchBar = '#full-screen-hero-search-input';

  const homeScreenListFirstItem = '#full-screen-hero-search-select-item-0';

  const homeScreenCheckInDate = '#full-screen-hero-check-in-input';

  const homeScreenCheckOutDate = '#full-screen-hero-check-out-input';
  
  const homeScreenGuestCount = '.guest-count-input__btn';

  export {dismissPromoModal, homeScreenLocationSearchBar, homeScreenListFirstItem, homeScreenCheckInDate, homeScreenCheckOutDate, homeScreenGuestCount };