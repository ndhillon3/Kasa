const searchResultsContent = '.list-page__content-list';

const searchResultsPageHeader = '.list-page__header';

const searchBar = '#nav-search-input';

export {searchResultsContent, searchResultsPageHeader, searchBar};
